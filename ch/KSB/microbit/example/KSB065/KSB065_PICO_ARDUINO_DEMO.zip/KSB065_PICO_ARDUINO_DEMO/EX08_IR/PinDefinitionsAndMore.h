#if defined(ARDUINO_ARCH_RP2040) // Arduino Nano Connect, Pi Pico with arduino-pico core https://github.com/earlephilhower/arduino-pico
//#define IR_RECEIVE_PIN      4  
#define IR_RECEIVE_PIN      12  
#endif
